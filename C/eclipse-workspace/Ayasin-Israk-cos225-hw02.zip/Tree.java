public class Tree {
	int id;
	int age;
	String species;
	
	public Tree(int id, int age, String species) {
		this.id=id;
		this.age=age;
		this.species=species;
	}
}
