public class Car {
	String manufacturer;
	String color;
	boolean handicap;
	
	public Car(String manufacturer, String color, boolean handicap) {
		this.color=color;
		this.manufacturer=manufacturer;
		this.handicap=handicap;
	}
}
